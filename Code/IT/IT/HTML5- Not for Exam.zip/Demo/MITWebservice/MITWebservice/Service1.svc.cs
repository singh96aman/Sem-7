﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
//using System.Web.Helpers;

namespace MITWebservice
{
    // NOTE: You can use the 'Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        static List<Achievement> achievements = new List<Achievement>();
        public bool AddAchievement(Achievement a)
        {
            achievements.Add(a);
            //TODO: Add to database
            return true;
        }

        public int GetAchievementCount()
        {
            return achievements.Count;
        }

        public List<Achievement> GetAchievements()
        {
            return achievements;
        }


        public VerifyAchievementResponse VerifyAttachment(VerifyAchievementRequest request)
        {
            var response = new VerifyAchievementResponse();

            response.Success = (request.Username == "admin" && request.Password == "admin");

            return response;
        }

        public void TestRest()
        {
            HttpWebRequest request = WebRequest.Create("http://localhost:51038/api/values") as HttpWebRequest;
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string json = null;
                    using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
                    {
                        json = reader.ReadToEnd();
                    }
                    //dynamic data = Json.Decode(json);
                }
            }

        }

        public int Add(int a, int b)
        {
            return a + b;
        }
    }
}
