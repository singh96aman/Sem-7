﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Web;

namespace MITWebservice
{
    [DataContract]
    public class Achievement
    {
        [DataMember]
        public int id {get; set;}

        [DataMember]
        public int StudentId;

        [DataMember]
        public string StudentName;

        [DataMember]
        public string AchievementType;

        [DataMember]
        public string Description;

        public bool Verified;
    }
}