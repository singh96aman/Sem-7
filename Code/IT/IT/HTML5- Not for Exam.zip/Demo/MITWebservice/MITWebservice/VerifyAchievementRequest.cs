﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;

namespace MITWebservice
{
    [MessageContract]
    public class VerifyAchievementRequest
    {
        [MessageHeader]
        public string Username;
        
        [MessageHeader]
        public string Password;

        [MessageBodyMember]
        public int AchievementId;

        [MessageBodyMember]
        public bool Verified;
    }

    [MessageContract]
    public class VerifyAchievementResponse
    {
        [MessageBodyMember]
        public bool Success;
    }
}