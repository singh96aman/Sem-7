﻿using System;
using System.Runtime.Serialization;

namespace WcfService7.DataModel
{
    [DataContract]
    public class Employee
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public String Name { get; set; }

        [DataMember]
        public String Department { get; set; }
    }
}