﻿
using System.Configuration;

namespace WcfService7.Helper
{
    public static class DbHelper
    {
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["MyCollegeDB"].ConnectionString;
        public const string QryInsertEmployee = "INSERT INTO Employee(id, name, department) VALUES (@id, @name, @department)";
        public const string QryGetEmployees = "SELECT * FROM Employee";
        

    }
}