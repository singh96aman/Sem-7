﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfService7.DataModel;
using System.Data.SqlClient;
using WcfService7.Helper;

namespace WcfService7
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public bool AddEmployee(Employee e)
        {
            bool success = true;
            try
            {
                var con = new SqlConnection(DbHelper.ConnectionString);
                var cmd = new SqlCommand(DbHelper.QryInsertEmployee, con);
                cmd.Parameters.AddWithValue("@id", e.Id);
                cmd.Parameters.AddWithValue("@name", e.Name);
                cmd.Parameters.AddWithValue("@department", e.Department);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                //employees.Add(e);
            }
            catch (Exception ex)
            {
                //TODO: Log the error
                success = false;
            }
            return success;
        }

        public Employee GetEmployee(string id)
        {
            string query = "SELECT * FROM Employee WHERE id=" + id;
            var emp = new Employee();

            try
            {
                using (var con = new SqlConnection(DbHelper.ConnectionString))
                {
                    using (var cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {                                
                                emp.Id = (int)reader["Id"];
                                emp.Name = reader["Name"].ToString();
                                emp.Department = reader["Department"].ToString();                                
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return emp;
        }

        public int GetEmployeeCount()
        {
            //return employees.Count;
            return 0;
        }

        public List<Employee> GetEmployees()
        {
            string query = DbHelper.QryGetEmployees;
            var emps = new List<Employee>();
            try
            {
                using (var con = new SqlConnection(DbHelper.ConnectionString))
                {
                    using (var cmd = new SqlCommand(query, con))
                    {
                        con.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                var emp = new Employee();
                                emp.Id = (int)reader["Id"];
                                emp.Name = reader["Name"].ToString();
                                emp.Department = reader["Department"].ToString();
                                emps.Add(emp);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
            return emps;        
        }
    }
}
